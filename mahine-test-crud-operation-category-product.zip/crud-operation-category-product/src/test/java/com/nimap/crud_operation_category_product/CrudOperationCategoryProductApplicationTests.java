package com.nimap.crud_operation_category_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperationCategoryProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
