package com.nimap.crud_operation_category_product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperationCategoryProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperationCategoryProductApplication.class, args);
	}

}
